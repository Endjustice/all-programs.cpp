# Mobile App Interface Design

## Overview

This is a sample mobile application demonstrating core Expo and React Native development patterns. The app showcases best practices for mobile UI design following iOS Human Interface Guidelines.

## Screen List

1. **Home Screen** - Main entry point with welcome message and example components
2. **Settings Screen** - App configuration and preferences (future expansion)

## Primary Content and Functionality

### Home Screen
- **Welcome Header**: Large, bold title with subtitle explaining the app purpose
- **Example Card**: Demonstrates NativeWind styling with Tailwind CSS
- **Call-to-Action Button**: Primary action button with haptic feedback
- **Content Area**: Scrollable content for extensibility

### Settings Screen (Future)
- Theme toggle (light/dark mode)
- App information and version
- About section

## Key User Flows

### Primary Flow: App Launch
1. User launches app
2. App displays Home screen with welcome message
3. User can tap "Get Started" button to explore features
4. Navigation via tab bar to access other screens

### Theme Toggle Flow (Future)
1. User navigates to Settings tab
2. User taps theme toggle
3. App switches between light and dark modes
4. Theme preference persists across sessions

## Color Choices

| Token | Light Mode | Dark Mode | Purpose |
|-------|-----------|-----------|---------|
| `primary` | #0a7ea4 | #0a7ea4 | Accent color for buttons and highlights |
| `background` | #ffffff | #151718 | Screen background |
| `surface` | #f5f5f5 | #1e2022 | Card and elevated surfaces |
| `foreground` | #11181C | #ECEDEE | Primary text |
| `muted` | #687076 | #9BA1A6 | Secondary text |
| `border` | #E5E7EB | #334155 | Dividers and borders |
| `success` | #22C55E | #4ADE80 | Success states |
| `warning` | #F59E0B | #FBBF24 | Warning states |
| `error` | #EF4444 | #F87171 | Error states |

## Design Principles

- **Mobile-First**: Optimized for portrait orientation (9:16) and one-handed usage
- **Apple HIG Compliance**: Follows iOS design standards for spacing, typography, and interactions
- **Accessibility**: Proper contrast ratios, readable font sizes, and touch targets ≥44pt
- **Performance**: Efficient rendering with FlatList for lists, proper memoization
- **Consistency**: Unified color palette and typography throughout the app
